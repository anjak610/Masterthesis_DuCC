﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;
using System.IO;
// tutorial: http://pterneas.com/2014/02/20/kinect-for-windows-version-2-color-depth-and-infrared-streams/
namespace Kinect_Streams
{
    public partial class MainWindow : Window
    {
        //Initialisiere ein Fenster, call Window_loaded
        public MainWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(Window_Loaded);
        }

        //Referenz Sensor und Streams
        KinectSensor _sensor;
        MultiSourceFrameReader _reader;

        //Sreams werden als Bitmap gespeichert, um sie im UI anzuzeigen
        WriteableBitmap wbmp;
        BitmapSource bmpSource;
        //Die gepeicherten Frames werden duzrchnummeriert
        int imageSerial;

        /// <summary>
        /// Wenn das fenster bereit ist und die Kinect aktiv, 
        /// so werden der Farb-, IR- und Tiefen-Stream gelesen
        /// </summary>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _sensor = KinectSensor.GetDefault();

            if (_sensor != null)
            {
                _sensor.Open();
                
                _reader = _sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Infrared | FrameSourceTypes.Depth);
                //MultiSourceFrameArrived event startet wenn einer der spezifizierten Frames bereit ist
                _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;
            }
            else 
            {
                Console.WriteLine("No Sensor ");
            }            
        }


        /// <summary>
        /// async function - nur ein Frame pro Sekunde wird gespeichert - Farb- und IR-Bild
        /// </summary>
        async Task PutTaskDelay()
        {
            //1 Sekunde
            await Task.Delay(1000);
            // PngBitmapEncoder speichert BitmapSource als PNG
            // Bilder werden mit imageSerial durchnummeriert
            PngBitmapEncoder encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bmpSource));
            //Die Bilder werden in "...\Kinect_IR_Stream\bin\Debug\img" gespeichert
            using (var fs = new FileStream("./img/" + (imageSerial++) + ".png", FileMode.Create, FileAccess.Write))
            {
                encoder.Save(fs);
            }
        }
        /// <summary>
        /// async function - nur ein Frame pro Sekunde wird gespeichert - Tiefenbild
        /// </summary>
        async Task DelayDepth(DepthFrame frame_depth)
        {
            await Task.Delay(1000);

            int width = frame_depth.FrameDescription.Width;
            int height = frame_depth.FrameDescription.Height;
            ushort[] depthData = new ushort[width * height];

            frame_depth.CopyFrameDataToArray(depthData);
            //Die Bilder werden in "...\Kinect_IR_Stream\bin\Debug\img" als MAT-Datei gespeichert
            new MATWriter("img_ir", "./imgD/" + (imageSerial++) + ".mat", depthData, height, width);
        }

        /// <summary>
        /// Funktionsaufruf, wenn Frame bereit steht
        /// </summary>
        async void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            //Frames werden seperat abgespeichert
            var reference = e.FrameReference.AcquireFrame();   
            var frame_rgb = reference.ColorFrameReference.AcquireFrame();
            var frame_ir = reference.InfraredFrameReference.AcquireFrame();
            var frame_depth = reference.DepthFrameReference.AcquireFrame();

            #region Farbbild
            using (frame_rgb)
            {
                if (frame_rgb != null)
                {
                    //Bildbreite und -höhe 
                    int width = frame_rgb.FrameDescription.Width;
                    int height = frame_rgb.FrameDescription.Height;
                    //32 bits per pixel - jeder Farbkanal hat 8 bits per pixel
                    PixelFormat format = PixelFormats.Bgr32;
                    //farbinformation wird abgespeichert
                    byte[] pixels = new byte[width * height * ((format.BitsPerPixel + 7) / 8)];
                    if (frame_rgb.RawColorImageFormat == ColorImageFormat.Bgra)
                    {
                        frame_rgb.CopyRawFrameDataToArray(pixels);
                    }
                    else
                    {
                        frame_rgb.CopyConvertedFrameDataToArray(pixels, ColorImageFormat.Bgra);
                    }

                    //Bitmap wird erzeugt
                    //width, height, dpix, dpiy, bgr32 - format, colour pallette, pixel information, stride 
                    int stride = width * format.BitsPerPixel / 8;
                    bmpSource = BitmapSource.Create(width, height, 96, 96, format, null, pixels, stride);

                    // WritableBitmap für UI
                    wbmp = new WriteableBitmap(bmpSource);
                    //camera = image control name in window
                    camera.Source = wbmp;
                    //Verzögerung
                    await PutTaskDelay();

                }
            }
            #endregion
            #region Tiefenbild
            using (frame_depth)
            {
                if(frame_depth != null)
                {
                    await DelayDepth(frame_depth);
                }
            }
            #endregion

            #region Infrarotbild
            using (frame_ir)
            {
                if (frame_ir != null)
                {
                    int width = frame_ir.FrameDescription.Width;
                    int height = frame_ir.FrameDescription.Height;
                    PixelFormat format = PixelFormats.Bgr32;

                    ushort[] infraredData = new ushort[width * height];
                    byte[] pixelData = new byte[width * height * (PixelFormats.Bgr32.BitsPerPixel + 7) / 8];

                    frame_ir.CopyFrameDataToArray(infraredData);

                    // der Kontrast wird erhöht
                    int colorIndex = 0;
                    for (int infraredIndex = 0; infraredIndex < infraredData.Length; ++infraredIndex)
                    {
                        ushort ir = infraredData[infraredIndex];
                        byte intensity = (byte)(ir >> 8);

                        pixelData[colorIndex++] = intensity; // B
                        pixelData[colorIndex++] = intensity; // G  
                        pixelData[colorIndex++] = intensity; // R

                        ++colorIndex;
                    }

                    int stride = width * format.BitsPerPixel / 8;
                    bmpSource = BitmapSource.Create(width, height, 96, 96, format, null, pixelData, stride);

                    // WritableBitmap für UI
                    wbmp = new WriteableBitmap(bmpSource);
                    camera.Source = wbmp;

                    await PutTaskDelay();

                }
            }
            #endregion
        }
    }
}
