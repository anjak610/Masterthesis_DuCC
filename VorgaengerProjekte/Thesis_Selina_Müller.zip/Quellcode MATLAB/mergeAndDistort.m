function [img_merged, img_merged_c, img_d_d] = mergeAndDistort( img_F, img_d_ud, f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, k1_F, k2_F, cameraParams_d, b_x, b_y, scale, colourCode)
    %Auflösung des Farbbildes
    [height_F, width_F, ~] = size(img_F); 
    
    %Das Tiefenbild wird verzeichnet 
    %fuer r wird ein moeglicher Wertebereich angegeben   
    ydata = [0:0.01:0.79];
    xdata = ydata + k1_F .* power(ydata,3) + k2_F .* power(ydata,5); 
    %Transponiere die Matrizen
    xdata = xdata.' ;
    ydata = ydata.' ;
    a0=[k1_F;k2_F];
    predicted = @(a,xdata) xdata + a(1)*power(xdata,3) +a(2)* power(xdata, 5);
    %ahat ergeben die VZ-Koeffizienten zum verzeichnen
    [ahat] =lsqcurvefit(predicted,a0,xdata,ydata);
    %cast zu Struct, da cameraParameter-Objekt read-only
    paramStruct = toStruct(cameraParams_d);
    %Änderung der Werte der Verzeichnung
    paramStruct.RadialDistortion(1) = ahat(1);
    paramStruct.RadialDistortion(2) = ahat(2);
    %undistort mit den berechneten Werten für k == Verzeichnung
    distortParams = cameraParameters(paramStruct);
    img_d_d = undistortImage(img_d_ud, distortParams);

    %% Skalierung von img_d
    img_d_d = imresize(img_d_d, scale, 'bilinear');
    p_dx = p_dx * scale;
    p_dy = p_dy * scale;
    f_d = f_d * scale;
	%neue Auflösung des Tiefenbildes 
    [height_d, width_d, ~] = size(img_d_d);
    %% Zusammenfuegen  
    %eine Matrix in der Groesse des Farbbildes wird deklariert,
    %um sie mit den abgebildeten Tiefenwerten zu befuellen 
    img_merged_c = img_F; 
    img_merged = zeros(height_F, width_F, 1,'double') ; %  height width 4 uint 16
    
        for i= 1: width_d
            for j = 1: height_d 
                Z = img_d_d(j,i);
                %falls Z 0 ist (an den Rändern) wird der Wert
                %interpoliert  
%                 if (Z == 0 && i < width_d && j < height_d )
%                     bil_1 = img_d_d(floor(j), floor(i) + 1);
%                     bil_2 = img_d_d((floor(j) + 1), floor(i) + 1);
%                     bil_3 = img_d_d((floor(j) + 1), floor(i));
%                     bil_4 = img_d_d(floor(j), floor(i));
% 
%                     d_x = abs(i - round(i));
%                     d_y = abs(j - round(j));
% 
%                     a = d_x * (1 - d_y);
%                     b = (1 - d_x) * (1 - d_y);
%                     c = d_x * d_y;
%                     d = (1 - d_x) * d_y;
% 
%                     Z = (b * bil_4) + (d * bil_1) + (a * bil_3) + (c * bil_2);
%                 end 
                if(Z ~= 0)
                   %cast Z (uint16) to doule
                    Z = double(Z);
                    %mit dem berechneten Z Wert kann zu der Koordinate vom
                    %Tiefenbild, die zugehörige Koordinate im Farbbild berchnet
                    %werden
                    u_F = round((f_F * (((i - p_dx)/f_d) - (b_x/Z))) + p_Fx);
                    v_F = round((f_F * (((j - p_dy)/f_d) - (b_y/Z))) + p_Fy);
                    %und dem Farbbild wird die Tiefeninfo hinzugefügt
                    
                    %Farbverfälschung der Tiefeninformation
                    if(u_F > 0 && u_F <  width_F && v_F > 0 && v_F < height_F )   
                        
                         if(Z >= colourCode && Z <= colourCode+20)
                            Z_c = 255 - (Z-colourCode) *6;
                            img_merged_c(v_F, u_F, 1) = Z_c;
                            img_merged_c(v_F, u_F, 2) = 0;
                            img_merged_c(v_F, u_F, 3) = 255; 
                        end
                        if(Z >= colourCode +20 && Z <= colourCode+40)
                            Z_c = 255 - (Z-colourCode+20) *6;
                            img_merged_c(v_F, u_F, 1) = Z_c;
                            img_merged_c(v_F, u_F, 2) = 255;
                            img_merged_c(v_F, u_F, 3) = 0; 
                        end
                        if(Z >= colourCode+40 && Z <= colourCode+60)
                            Z_c = 255 - (Z-colourCode+40) *6;
                            img_merged_c(v_F, u_F, 1) = 0;
                            img_merged_c(v_F, u_F, 2) = 255;
                            img_merged_c(v_F, u_F, 3) = Z_c; 
                        end
                        if(Z >= colourCode+60 && Z <= colourCode+80)
                            Z_c = 255 - (Z-colourCode+60) *6;
                            img_merged_c(v_F, u_F, 1) = 0;
                            img_merged_c(v_F, u_F, 2) = Z_c;
                            img_merged_c(v_F, u_F, 3) = 255; 
                        end
                        if(Z >= colourCode+80 && Z <= colourCode+100)
                            Z_c = 255 - (Z-colourCode+80) *6;
                            img_merged_c(v_F, u_F, 1) = 255;
                            img_merged_c(v_F, u_F, 2) = Z_c;
                            img_merged_c(v_F, u_F, 3) = 0; 
                        end
                        %Abspeicherung der Tiefeninformation
                        img_merged(v_F, u_F) = Z;                         
                    end %if(u_F > 0 && v_F > 0)  
                end %if(Z ~= 0)  
            end %for j = 1: height_d
        end
       
       img_merged =  imcrop(img_merged, [1 1 width_F height_F]);
    
end
