function [img_merged, img_merged_c, img_d_d, list_corr_F, list_corr_ir, b_x, b_y] = workflow()
    
    %% Kameraparameter importieren
    cameraParams_d = importdata('cameraParams_d.mat');
    cameraParams_F = importdata('cameraParams_F.mat');
    p_Fx = cameraParams_F.PrincipalPoint(1);
    p_Fy = cameraParams_F.PrincipalPoint(2);
    p_dx = round(cameraParams_d.PrincipalPoint(1));
    p_dy = round(cameraParams_d.PrincipalPoint(2));
    f_d = ((cameraParams_d.FocalLength(1)) + (cameraParams_d.FocalLength(2))) / 2;
    f_F = ((cameraParams_F.FocalLength(1)) + (cameraParams_F.FocalLength(2))) / 2;
    k1_F = cameraParams_F.RadialDistortion(1);
    k2_F = cameraParams_F.RadialDistortion(2);

    
    %% Bilder laden 
    img_F = imread('img_F.jpg');
    img_d = importdata('img_d.mat');
    
    %% img__corr sind die Aufnahmen des großen Schachbretts 
    % sie werden zur Berechnug des Versatzes benötigt
    img_d_checker = importdata('img_d_corr.mat');  
    img_F_checker = imread('img_F_corr.jpg');
    img_ir_checker = imread('img_ir_corr.png');
    
    %% Orientierungen der Tiefen- und IR-Bilder müssen angepasst werden
    img_d = rot90(img_d, -1);
    img_d_checker = rot90(img_d_checker, -1);
    img_ir_checker = flip(img_ir_checker, 2); 
    
    %% Der Kontrast des IR-Bildes wird erhöt um eine Kantenerkennung zu erleichtern
    img_ir_checker = img_ir_checker(:, :, :) * 10;

     %% die Bilder werden von Verzeichnung befreit
    img_d_ud = undistortImage(img_d, cameraParams_d);
    img_F_checker_ud = undistortImage(img_F_checker, cameraParams_F);
    img_ir_checker_ud = undistortImage(img_ir_checker, cameraParams_d);
    img_d_checker_ud = undistortImage(img_d_checker, cameraParams_d);

    %% Skalierungsfaktor
    scale = 1;
    %% Quadratgröße des Schachbrettmusters
    squareSize = 54; %mittleres: 37 großes: 54 kleines Schacbrett: 23
    %% Bereich, von dem ab Tiefeninfirmation farblich dargestellt werden soll
    colourCode = 1785;

    %% manuelle Auswahl der äußeren Eckpunkte des Schacbrettes
    [points_F, points_ir] = getPixelValues(img_F_checker_ud, img_ir_checker_ud);
    %% Versatz soll mit den manuell ausgewählten Punkten berechnet werden
    [b_x, b_y] = estimate_b (f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, points_ir, points_F, img_d_checker_ud);
    %% Die Korrespondenzen werden automatisch angelegt
    [list_corr_F, list_corr_ir] = correspondences_F_ir (img_ir_checker_ud,img_d_checker_ud, img_F_checker_ud, f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, b_x, b_y, squareSize);
    %% daraus wird der Versatz genauer berechnet
    [b_x, b_y] = estimate_b (f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, list_corr_ir, list_corr_F, img_d_checker_ud);     
    %% das Tiefenbild wird verzeichnet, skaliert und auf das Farbbild abgebildet
    [img_merged, img_merged_c, img_d_d] = mergeAndDistort( img_F, img_d_ud, f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, k1_F, k2_F,cameraParams_d, b_x, b_y, scale, colourCode);
    
end
