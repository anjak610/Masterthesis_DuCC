function [list_corr_F, list_corr_ir] = new_correspondences_F_ir (img_ir_ud, img_d_ud, img_F_ud, f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, b_x, b_y, squareSize)
    
    %Bilder in Graubild umwandeln
    img_F_ud = rgb2gray(img_F_ud);
    img_ir_ud = rgb2gray(img_ir_ud);
    %Kantenerkennung
    list_ir = detectCheckerboardPoints(img_ir_ud);
    list_F = detectCheckerboardPoints(img_F_ud);
   
    list_corr_F = cell(1, 2);
    list_corr_ir = cell(1, 2);
    %index für die Korrespondenzen-Liste
    k = 1;
    
    for i = 1:max(size(list_ir))
        y_ir = list_ir(i,2);
        x_ir = list_ir(i,1);
        %Z - Tiefenwert
        Z = img_d_ud(round(y_ir), round(x_ir));
        if (Z ~= 0)
          %cast Z (uint16) to doule
            Z = double(Z);
            %u_ir ergibt sich durch Abzug des Hauptpunktes aus den
            %abgespeicherten Koordinaten des IR-/Tiefenbildes
            u_ir = (x_ir - p_dx);
            v_ir = (y_ir - p_dy);
            %Farbbildkoordinaten aus den Tiefenkoordinaten berechnen
            u_F = f_F * (((u_ir)/f_d) - (b_x/Z));
            v_F = f_F * (((v_ir)/f_d) - (b_y/Z));

            %durch die Liste der tatsächlichen Farbwerte iterieren 
            for j = 1: max(size(list_F))
                %Suchfenster berechnen
                D_max = abs((squareSize * ((Z - f_F) / f_F))/2);
                %gu_F_c ist der tatsächliche Wert der Farbbildkoordinate
                u_F_c = (list_F(j,1) - p_Fx);
                v_F_c = (list_F(j,2) - p_Fy);

                %falls es einen Wert fuer u_F,v_F der sich in der Liste list_F befindet 
                %der sich im Suchfenster um den berechneten Wert befindet
                if (u_F_c <= (u_F + D_max)) &&  (u_F_c >= (u_F - D_max)) && (v_F_c <= (v_F + D_max)) && (v_F_c >= (v_F - D_max))

                    %übereinstimmende Koordinaten in Liste speichern
                    list_corr_F{k, 2} = list_F(j,1);
                    list_corr_F{k, 1} = list_F(j,2);
                    list_corr_ir{k, 2} = list_ir(i,1);
                    list_corr_ir{k, 1} = list_ir(i,2);
                    k = k + 1;
                end 
            end  
        end        
    end
end