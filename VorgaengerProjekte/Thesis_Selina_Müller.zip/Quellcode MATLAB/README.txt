Folgende Dateien müssen im selben Ordner wie der Quellcode abgespeichert werden:    
    cameraParams_d 
    cameraParams_F 
    img_F 
    img_d 
    img_d_checker  
    img_F_checker 
    img_ir_checker 

Beim Starten des workflow.m-Scripts öffnet sich das Farbbild, 
an die äußeren Ränder zoomen.
Das Drücken jeder beliebiger Taste beendet das Zoomen.
Nun kann die Kante ausgewählt werden.
(Doppelklick der "Lupe" zoomt ganz aus dem Bild heraus.)
Nach dem Auswählen der vier Eckpunkte des Schachbretts, öffnet sich das IR-Bild.
Vorgang wiederholen.

Folgende Parameter müssen im workflow.m Script angegeben werden.
    %% Skalierungsfaktor
    scale = 1;
    %% Quadratgröße des Schachbrettmusters
    squareSize = 54; 
    %% Bereich, von dem ab Tiefeninfirmation farblich dargestellt werden soll
    colourCode = 1785;

img_merged_c ist das Farbbild mit farbverfälschter Tiefeninformation.

