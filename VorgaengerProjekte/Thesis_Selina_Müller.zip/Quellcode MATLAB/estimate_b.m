function [b_x, b_y] = estimate_b (f_d, p_dx, p_dy, f_F, p_Fx, p_Fy, points_d, points_F, img_d_ud)
    
    % Anzahl an gespeicherten Punktpaaren
    index_length = max(size(points_d));
    
    % falls die Korrespondenzen als cellarray abgespeichert sind
    if iscell(points_d) == 1      
        points_d = cell2mat(points_d);
        points_F = cell2mat(points_F);
    end
    
    % Initialisierung der Variablen
    b_x = 0;
    b_y = 0;
    div = 0;
    
    for i= 1: index_length
        %get Z value from d-img from given ir-values
        y_ir = points_d(i,1);
        x_ir = points_d(i,2); 
        y_F = points_F(i,1);
        x_F = points_F(i,2);
        Z = img_d_ud(round(y_ir), round(x_ir));
        % if Z is not 0, calculate b
        if (Z ~= 0)
            %cast Z (uint16) to doule
            Z = double(Z);
            %div wird um 1 erhöht
            div = div + 1;

            %%b_x
            u_ir = x_ir - p_dx; %principal point abziehen
            u_F = x_F - p_Fx;
            b = ((u_ir/f_d) - (u_F/f_F)) * Z;
            %disp(b);
            b_x = b_x + b;

            %%b_y
            v_ir = y_ir - p_dy; %principal point abziehen
            v_F = y_F - p_Fy;   %principal point abziehen
            b = ((v_ir/f_d) - (v_F/f_F)) * Z;
            %disp(b);
            b_y = b_y + b;
        end 

    end
    %calculate mean
    b_x = (b_x/div);
    b_y = (b_y /div);

end