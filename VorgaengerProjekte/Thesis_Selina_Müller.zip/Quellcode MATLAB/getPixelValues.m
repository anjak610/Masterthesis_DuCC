function [points_F, points_ir] = getPixelValues(img_F_ud, img_ir_ud)
    
    % wie viele Punkte sollen gesammelt werden
    q_points = 4;
    
    %Zoom ist eingeschaltet, das Drücken einer Taste beendet den Zoom
    % Erster Durchgang mit dem Farbbild, zweiter mit dem IR-Bild
    points_F = zeros(q_points,2);
    imshow(img_F_ud);
    for i=1:q_points
        zoom on;
        pause() 
        zoom off; 
        [x, y] = ginput(1); 
        points_F(i,2) = x;
        points_F(i,1) = y;
    end
    points_ir = zeros(q_points,2);
    imshow(img_ir_ud); 
    for i=1:q_points
        zoom on;
        pause() 
        zoom off; 
        [x, y] = ginput(1); 
        points_ir(i,2) = x;
        points_ir(i,1) = y;
    end
end