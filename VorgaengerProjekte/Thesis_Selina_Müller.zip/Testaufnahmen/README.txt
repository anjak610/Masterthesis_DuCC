img_F - Farbild der Szene (externe Kamera)
img_ir - Infrarotbil der Szene (Kinect)
img_d - Tiefenbild der Szene (Kinect)
-----------------------------------------------------------------
img_F_corr - Farbbild von Schachbrett in Szene (externe Kamera)
img_ir_corr- Infrarotbild von Schachbrett in Szene (Kinect)
img_d_corr - Tiefenbild von Schachbrett in Szene (Kinect)
-----------------------------------------------------------------
cameraParams_F - Kameraparameter der externen Farbkamera
cameraParams_d - Kameraparameter der Tiefen-/IR-Kamera
